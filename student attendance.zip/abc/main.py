from fastapi import FastAPI, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import FileResponse
from pydantic import BaseModel
import database  # Importing our sqlite3-based database.py

# 1. Initialize FastAPI App
app = FastAPI()

# 2. Initialize Database on Startup
@app.on_event("startup")
def startup():
    database.init_db()

# 3. Enable CORS
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# 4. Pydantic Model for Data Validation
class AttendanceCreate(BaseModel):
    student_name: str
    usn: str
    date: str
    status: str

# --- API ROUTES ---

@app.get("/")
def read_root():
    return FileResponse("index.html")

@app.post("/add-attendance")
def add_attendance(attendance: AttendanceCreate):
    try:
        new_id = database.add_attendance(
            attendance.student_name,
            attendance.usn,
            attendance.date,
            attendance.status
        )
        return {"message": "Attendance added successfully!", "id": new_id}
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))

@app.get("/attendance")
def get_all_attendance():
    try:
        records = database.get_attendance()
        return records
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))

@app.delete("/attendance/{id}")
def delete_attendance(id: int):
    try:
        success = database.delete_attendance(id)
        if not success:
            raise HTTPException(status_code=404, detail="Record not found")
        return {"message": f"Record with ID {id} deleted successfully"}
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))

# Run with: python -m uvicorn main:app --host 127.0.0.1 --port 8001 --reload
