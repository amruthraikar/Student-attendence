import sqlite3

# 1. Define the Database Name
DB_NAME = "attendance.db"

def get_db_connection():
    """Creates a connection to the SQLite database."""
    conn = sqlite3.connect(DB_NAME)
    # This allows us to access columns by name (e.g. row['student_name'])
    conn.row_factory = sqlite3.Row
    return conn

def init_db():
    """Initializes the database and creates the table if it doesn't exist."""
    conn = get_db_connection()
    cursor = conn.cursor()
    
    # Writing raw SQL to create the table
    cursor.execute('''
        CREATE TABLE IF NOT EXISTS attendance (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            student_name TEXT NOT NULL,
            usn TEXT NOT NULL,
            date TEXT NOT NULL,
            status TEXT NOT NULL
        )
    ''')
    
    conn.commit()
    conn.close()
    print("Database initialized with SQL table!")

def add_attendance(name, usn, date, status):
    """Adds a new attendance record using raw SQL INSERT."""
    conn = get_db_connection()
    cursor = conn.cursor()
    
    query = "INSERT INTO attendance (student_name, usn, date, status) VALUES (?, ?, ?, ?)"
    cursor.execute(query, (name, usn, date, status))
    
    conn.commit()
    new_id = cursor.lastrowid
    conn.close()
    return new_id

def get_attendance():
    """Fetches all records using raw SQL SELECT."""
    conn = get_db_connection()
    cursor = conn.cursor()
    
    cursor.execute("SELECT * FROM attendance")
    rows = cursor.fetchall()
    
    # Convert sqlite3.Row objects to dictionaries for JSON response
    records = [dict(row) for row in rows]
    
    conn.close()
    return records

def delete_attendance(record_id):
    """Deletes a record using raw SQL DELETE."""
    conn = get_db_connection()
    cursor = conn.cursor()
    
    cursor.execute("DELETE FROM attendance WHERE id = ?", (record_id,))
    
    deleted = cursor.rowcount > 0
    conn.commit()
    conn.close()
    return deleted

# Run initialization when this script is imported
if __name__ == "__main__":
    init_db()
